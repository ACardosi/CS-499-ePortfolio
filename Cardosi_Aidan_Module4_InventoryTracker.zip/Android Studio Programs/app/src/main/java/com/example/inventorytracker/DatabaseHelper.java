package com.example.inventorytracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database information
    private static final String DATABASE_NAME = "InventoryTracker.db";
    private static final int DATABASE_VERSION = 1;

    // Users table
    public static final String TABLE_USERS = "users";
    public static final String USER_ID = "id";
    public static final String USERNAME = "username";
    public static final String PASSWORD = "password";

    // Inventory table
    public static final String TABLE_INVENTORY = "inventory";
    public static final String ITEM_ID = "id";
    public static final String ITEM_NAME = "item_name";
    public static final String ITEM_QUANTITY = "quantity";
    public static final String ITEM_DESCRIPTION = "description";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Create the table used to store user accounts.
        String createUsersTable =
                "CREATE TABLE " + TABLE_USERS + " (" +
                        USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        USERNAME + " TEXT UNIQUE NOT NULL, " +
                        PASSWORD + " TEXT NOT NULL)";

        // Create the table used to store inventory items.
        String createInventoryTable =
                "CREATE TABLE " + TABLE_INVENTORY + " (" +
                        ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        ITEM_NAME + " TEXT NOT NULL, " +
                        ITEM_QUANTITY + " INTEGER NOT NULL, " +
                        ITEM_DESCRIPTION + " TEXT)";

        db.execSQL(createUsersTable);
        db.execSQL(createInventoryTable);
    }

    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);

        onCreate(db);
    }

    // CREATE - Add a new inventory item.
    public boolean addInventoryItem(
            String name,
            int quantity,
            String description) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(ITEM_NAME, name);
        values.put(ITEM_QUANTITY, quantity);
        values.put(ITEM_DESCRIPTION, description);

        long result = db.insert(
                TABLE_INVENTORY,
                null,
                values
        );

        return result != -1;
    }

    // READ - Get all inventory items.
    public Cursor getAllInventoryItems() {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM " + TABLE_INVENTORY,
                null
        );
    }


    public List<InventoryItem> getInventoryItemList() {

        List<InventoryItem> inventoryItems =
                new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_INVENTORY,
                null,
                null,
                null,
                null,
                null,
                null
        );

        if (cursor.moveToFirst()) {

            int idIndex =
                    cursor.getColumnIndexOrThrow(ITEM_ID);

            int nameIndex =
                    cursor.getColumnIndexOrThrow(ITEM_NAME);

            int quantityIndex =
                    cursor.getColumnIndexOrThrow(ITEM_QUANTITY);

            int descriptionIndex =
                    cursor.getColumnIndexOrThrow(ITEM_DESCRIPTION);

            do {

                int id = cursor.getInt(idIndex);

                String name =
                        cursor.getString(nameIndex);

                int quantity =
                        cursor.getInt(quantityIndex);

                String description =
                        cursor.getString(descriptionIndex);

                InventoryItem item =
                        new InventoryItem(
                                id,
                                name,
                                quantity,
                                description
                        );

                inventoryItems.add(item);

            } while (cursor.moveToNext());
        }

        cursor.close();

        return inventoryItems;
    }


    // UPDATE - Change an existing inventory item.
    public boolean updateInventoryItem(
            int id,
            String name,
            int quantity,
            String description) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(ITEM_NAME, name);
        values.put(ITEM_QUANTITY, quantity);
        values.put(ITEM_DESCRIPTION, description);

        int result = db.update(
                TABLE_INVENTORY,
                values,
                ITEM_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }

    // DELETE - Remove an inventory item.
    public boolean deleteInventoryItem(int id) {

        SQLiteDatabase db = this.getWritableDatabase();

        int result = db.delete(
                TABLE_INVENTORY,
                ITEM_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }

    // Create a new user account.
    public boolean createUser(
            String username,
            String password) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(USERNAME, username);
        values.put(PASSWORD, password);

        long result = db.insert(
                TABLE_USERS,
                null,
                values
        );

        return result != -1;
    }

    // Check whether a username and password exist.
    public boolean checkUser(
            String username,
            String password) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{USER_ID},
                USERNAME + "=? AND " + PASSWORD + "=?",
                new String[]{username, password},
                null,
                null,
                null
        );

        boolean userExists = cursor.getCount() > 0;

        cursor.close();

        return userExists;
    }
}