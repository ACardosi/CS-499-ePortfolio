package com.example.inventorytracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editUsername;
    private EditText editPassword;

    private Button buttonLogin;
    private Button buttonCreateAccount;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        // Connect Java variables to the controls in activity_main.xml.
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);

        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        // Open the SQLite database.
        databaseHelper = new DatabaseHelper(this);

        // Check the username and password when Login is pressed.
        buttonLogin.setOnClickListener(v -> loginUser());

        // Create a new account when Create Account is pressed.
        buttonCreateAccount.setOnClickListener(v -> createAccount());
    }

    /**
     * Checks the username and password against the users table.
     */
    private void loginUser() {

        String username =
                editUsername.getText().toString().trim();

        String password =
                editPassword.getText().toString().trim();

        // Make sure a username was entered.
        if (username.isEmpty()) {

            editUsername.setError(
                    "Please enter your username."
            );

            editUsername.requestFocus();

            return;
        }

        // Make sure a password was entered.
        if (password.isEmpty()) {

            editPassword.setError(
                    "Please enter your password."
            );

            editPassword.requestFocus();

            return;
        }

        // Check the username and password in SQLite.
        boolean validUser =
                databaseHelper.checkUser(
                        username,
                        password
                );

        if (validUser) {

            Toast.makeText(
                    this,
                    "Login successful.",
                    Toast.LENGTH_SHORT
            ).show();

            // Open the Inventory screen.
            Intent intent = new Intent(
                    MainActivity.this,
                    InventoryActivity.class
            );

            startActivity(intent);

        } else {

            Toast.makeText(
                    this,
                    "Invalid username or password.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    /**
     * Creates a new user account and saves it to SQLite.
     */
    private void createAccount() {

        String username =
                editUsername.getText().toString().trim();

        String password =
                editPassword.getText().toString().trim();

        // Make sure a username was entered.
        if (username.isEmpty()) {

            editUsername.setError(
                    "Please enter a username."
            );

            editUsername.requestFocus();

            return;
        }

        // Make sure a password was entered.
        if (password.isEmpty()) {

            editPassword.setError(
                    "Please enter a password."
            );

            editPassword.requestFocus();

            return;
        }

        // Require a basic password length.
        if (password.length() < 4) {

            editPassword.setError(
                    "Password must be at least 4 characters."
            );

            editPassword.requestFocus();

            return;
        }

        // Attempt to save the new account.
        boolean accountCreated =
                databaseHelper.createUser(
                        username,
                        password
                );

        if (accountCreated) {

            Toast.makeText(
                    this,
                    "Account created successfully. You can now log in.",
                    Toast.LENGTH_LONG
            ).show();

            // Clear the password for security.
            editPassword.setText("");

        } else {

            Toast.makeText(
                    this,
                    "Username already exists. Please choose another username.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }
}