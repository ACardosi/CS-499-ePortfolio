package com.example.inventorytracker;

public class InventoryItem {

    private final int id;
    private final String name;
    private final int quantity;
    private final String description;

    public InventoryItem(
            int id,
            String name,
            int quantity,
            String description) {

        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.description = description;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getDescription() {
        return description;
    }
}