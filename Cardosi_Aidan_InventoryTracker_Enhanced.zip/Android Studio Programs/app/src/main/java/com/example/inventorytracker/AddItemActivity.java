package com.example.inventorytracker;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class AddItemActivity extends AppCompatActivity {

    private EditText editItemName;
    private EditText editQuantity;
    private EditText editDescription;

    private Button buttonSave;
    private Button buttonCancel;

    private DatabaseHelper databaseHelper;

    // -1 means a new item is being added.
    // Any other value means an existing item is being edited.
    private int itemId = -1;

    // Inventory quantity that triggers a low inventory alert.
    private static final int LOW_INVENTORY_THRESHOLD = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_add_item);

        // Connect Java variables to XML controls.
        editItemName = findViewById(R.id.editItemName);
        editQuantity = findViewById(R.id.editQuantity);
        editDescription = findViewById(R.id.editDescription);

        buttonSave = findViewById(R.id.buttonSave);
        buttonCancel = findViewById(R.id.buttonCancel);

        // Open the SQLite database.
        databaseHelper = new DatabaseHelper(this);

        /*
         * If an ITEM_ID was sent to this Activity,
         * the user is editing an existing item.
         */
        if (getIntent().hasExtra("ITEM_ID")) {

            itemId = getIntent().getIntExtra(
                    "ITEM_ID",
                    -1
            );

            String itemName =
                    getIntent().getStringExtra("ITEM_NAME");

            int quantity =
                    getIntent().getIntExtra(
                            "ITEM_QUANTITY",
                            0
                    );

            String description =
                    getIntent().getStringExtra(
                            "ITEM_DESCRIPTION"
                    );

            // Display existing information.
            editItemName.setText(itemName);
            editQuantity.setText(String.valueOf(quantity));
            editDescription.setText(description);
        }

        // Save or update the inventory item.
        buttonSave.setOnClickListener(v -> saveItem());

        // Return to Inventory without saving.
        buttonCancel.setOnClickListener(v -> finish());
    }

    private void saveItem() {

        String itemName =
                editItemName
                        .getText()
                        .toString()
                        .trim();

        String quantityText =
                editQuantity
                        .getText()
                        .toString()
                        .trim();

        String description =
                editDescription
                        .getText()
                        .toString()
                        .trim();

        // Validate item name.
        if (itemName.isEmpty()) {

            editItemName.setError(
                    "Please enter an item name."
            );

            editItemName.requestFocus();
            return;
        }

        // Validate quantity.
        if (quantityText.isEmpty()) {

            editQuantity.setError(
                    "Please enter a quantity."
            );

            editQuantity.requestFocus();
            return;
        }

        int quantity;

        try {

            quantity = Integer.parseInt(quantityText);

        } catch (NumberFormatException e) {

            editQuantity.setError(
                    "Please enter a valid quantity."
            );

            editQuantity.requestFocus();
            return;
        }

        // Inventory cannot be negative.
        if (quantity < 0) {

            editQuantity.setError(
                    "Quantity cannot be negative."
            );

            editQuantity.requestFocus();
            return;
        }

        boolean success;

        /*
         * itemId == -1 means this is a new item.
         * Otherwise update the existing item.
         */
        if (itemId == -1) {

            success =
                    databaseHelper.addInventoryItem(
                            itemName,
                            quantity,
                            description
                    );

        } else {

            success =
                    databaseHelper.updateInventoryItem(
                            itemId,
                            itemName,
                            quantity,
                            description
                    );
        }

        if (success) {

            if (itemId == -1) {

                Toast.makeText(
                        this,
                        "Item saved successfully.",
                        Toast.LENGTH_SHORT
                ).show();

            } else {

                Toast.makeText(
                        this,
                        "Item updated successfully.",
                        Toast.LENGTH_SHORT
                ).show();
            }

            /*
             * Check whether the quantity is low enough
             * to trigger an SMS alert.
             */
            if (quantity <= LOW_INVENTORY_THRESHOLD) {

                sendLowInventorySms(
                        itemName,
                        quantity
                );
            }

            // Return to Inventory.
            finish();

        } else {

            Toast.makeText(
                    this,
                    "Unable to save item.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    /**
     * Sends an SMS when an inventory item's quantity
     * reaches the low inventory threshold.
     */
    private void sendLowInventorySms(
            String itemName,
            int quantity) {

        // Read the saved SMS settings.
        SharedPreferences preferences =
                getSharedPreferences(
                        "sms_settings",
                        MODE_PRIVATE
                );

        boolean smsEnabled =
                preferences.getBoolean(
                        "sms_enabled",
                        false
                );

        String phoneNumber =
                preferences.getString(
                        "phone_number",
                        ""
                );

        /*
         * If the user did not enable SMS notifications,
         * do nothing. The rest of the app continues normally.
         */
        if (!smsEnabled) {
            return;
        }

        // Make sure a phone number exists.
        if (phoneNumber == null ||
                phoneNumber.trim().isEmpty()) {

            return;
        }

        /*
         * Check the Android SEND_SMS permission.
         * If permission was denied, do not attempt
         * to send an SMS.
         */
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) != PackageManager.PERMISSION_GRANTED) {

            return;
        }

        String message =
                "Low Inventory Alert! " +
                        itemName +
                        " has only " +
                        quantity +
                        " item(s) remaining.";

        try {

            SmsManager smsManager =
                    SmsManager.getDefault();

            smsManager.sendTextMessage(
                    phoneNumber,
                    null,
                    message,
                    null,
                    null
            );

            Toast.makeText(
                    this,
                    "Low inventory SMS alert sent.",
                    Toast.LENGTH_LONG
            ).show();

        } catch (Exception e) {

            /*
             * SMS failure should never prevent the
             * inventory system from functioning.
             */
            Toast.makeText(
                    this,
                    "Unable to send SMS alert.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}