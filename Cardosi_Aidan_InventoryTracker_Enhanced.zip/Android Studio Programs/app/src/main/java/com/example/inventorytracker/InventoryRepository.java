package com.example.inventorytracker;

import android.content.Context;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

public class InventoryRepository {

    private final DatabaseHelper databaseHelper;

    public InventoryRepository(Context context) {
        databaseHelper = new DatabaseHelper(context);
    }

    /**
     * Returns all inventory items as InventoryItem objects.
     */
    public List<InventoryItem> getAllItems() {

        List<InventoryItem> items = new ArrayList<>();

        Cursor cursor =
                databaseHelper.getAllInventoryItems();

        try {

            while (cursor.moveToNext()) {

                int id = cursor.getInt(
                        cursor.getColumnIndexOrThrow(
                                DatabaseHelper.ITEM_ID
                        )
                );

                String name = cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                DatabaseHelper.ITEM_NAME
                        )
                );

                int quantity = cursor.getInt(
                        cursor.getColumnIndexOrThrow(
                                DatabaseHelper.ITEM_QUANTITY
                        )
                );

                String description = cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                DatabaseHelper.ITEM_DESCRIPTION
                        )
                );

                InventoryItem item =
                        new InventoryItem(
                                id,
                                name,
                                quantity,
                                description
                        );

                items.add(item);
            }

        } finally {

            cursor.close();
        }

        return items;
    }

    /**
     * Deletes an inventory item.
     */
    public boolean deleteItem(int id) {

        return databaseHelper
                .deleteInventoryItem(id);
    }
}