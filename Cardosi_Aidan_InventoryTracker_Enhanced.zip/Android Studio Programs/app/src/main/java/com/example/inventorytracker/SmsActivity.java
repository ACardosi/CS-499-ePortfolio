package com.example.inventorytracker;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SmsActivity extends AppCompatActivity {

    private EditText editPhoneNumber;
    private Button buttonEnableSms;
    private TextView textPermissionStatus;

    private ActivityResultLauncher<String> smsPermissionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_sms);

        editPhoneNumber = findViewById(R.id.editPhoneNumber);
        buttonEnableSms = findViewById(R.id.buttonEnableSms);
        textPermissionStatus = findViewById(R.id.textPermissionStatus);

        /*
         * This handles the user's response to the Android
         * SEND_SMS permission request.
         */
        smsPermissionLauncher =
                registerForActivityResult(
                        new ActivityResultContracts.RequestPermission(),
                        isGranted -> {

                            if (isGranted) {

                                textPermissionStatus.setText(
                                        "Permission Status: Granted"
                                );

                                saveSmsSettings();

                                Toast.makeText(
                                        this,
                                        "SMS notifications enabled.",
                                        Toast.LENGTH_SHORT
                                ).show();

                            } else {

                                textPermissionStatus.setText(
                                        "Permission Status: Denied"
                                );

                                /*
                                 * SMS will not be available, but the
                                 * rest of the application continues
                                 * to function normally.
                                 */
                                getSharedPreferences(
                                        "sms_settings",
                                        MODE_PRIVATE
                                )
                                        .edit()
                                        .putBoolean(
                                                "sms_enabled",
                                                false
                                        )
                                        .apply();

                                Toast.makeText(
                                        this,
                                        "SMS permission denied. The rest of the app will continue to work.",
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        }
                );

        loadSavedSettings();

        buttonEnableSms.setOnClickListener(v -> enableSms());
    }

    private void enableSms() {

        String phoneNumber =
                editPhoneNumber
                        .getText()
                        .toString()
                        .trim();

        if (phoneNumber.isEmpty()) {

            editPhoneNumber.setError(
                    "Please enter a phone number."
            );

            editPhoneNumber.requestFocus();

            return;
        }

        /*
         * Check whether SEND_SMS has already been granted.
         */
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED) {

            textPermissionStatus.setText(
                    "Permission Status: Granted"
            );

            saveSmsSettings();

            Toast.makeText(
                    this,
                    "SMS notifications enabled.",
                    Toast.LENGTH_SHORT
            ).show();

        } else {

            /*
             * Ask Android for permission.
             * Android displays the permission dialog.
             */
            smsPermissionLauncher.launch(
                    Manifest.permission.SEND_SMS
            );
        }
    }

    private void saveSmsSettings() {

        String phoneNumber =
                editPhoneNumber
                        .getText()
                        .toString()
                        .trim();

        /*
         * Save the user's phone number and notification
         * preference so they remain available when the
         * application is restarted.
         */
        getSharedPreferences(
                "sms_settings",
                MODE_PRIVATE
        )
                .edit()
                .putString(
                        "phone_number",
                        phoneNumber
                )
                .putBoolean(
                        "sms_enabled",
                        true
                )
                .apply();
    }

    private void loadSavedSettings() {

        String phoneNumber =
                getSharedPreferences(
                        "sms_settings",
                        MODE_PRIVATE
                )
                        .getString(
                                "phone_number",
                                ""
                        );

        editPhoneNumber.setText(phoneNumber);

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED) {

            textPermissionStatus.setText(
                    "Permission Status: Granted"
            );

        } else {

            textPermissionStatus.setText(
                    "Permission Status: Not Granted"
            );
        }
    }
}