package com.example.inventorytracker;

import android.content.Context;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

public class InventoryRepository {

    private final DatabaseHelper databaseHelper;

    public InventoryRepository(Context context) {
        databaseHelper = new DatabaseHelper(context);
    }

    /**
     * Returns all inventory items from the database.
     */
    public List<InventoryItem> getAllItems() {

        Cursor cursor =
                databaseHelper.getAllInventoryItems();

        return convertCursorToList(cursor);
    }

    /**
     * Searches for inventory items by name.
     *
     * The filtering is performed by SQLite instead
     * of loading every item and filtering in Java.
     */
    public List<InventoryItem> searchItems(
            String searchText) {

        Cursor cursor =
                databaseHelper.searchInventoryItems(
                        searchText
                );

        return convertCursorToList(cursor);
    }

    /**
     * Returns inventory items at or below
     * the specified quantity.
     *
     * The filtering is performed directly
     * by SQLite.
     */
    public List<InventoryItem> getLowStockItems(
            int threshold) {

        Cursor cursor =
                databaseHelper.getLowStockInventoryItems(
                        threshold
                );

        return convertCursorToList(cursor);
    }

    /**
     * Deletes an inventory item.
     */
    public boolean deleteItem(int id) {

        return databaseHelper
                .deleteInventoryItem(id);
    }

    /**
     * Converts database query results into
     * InventoryItem objects.
     *
     * This prevents duplicate Cursor-reading
     * code throughout the repository.
     */
    private List<InventoryItem> convertCursorToList(
            Cursor cursor) {

        List<InventoryItem> items =
                new ArrayList<>();

        try {

            int idIndex =
                    cursor.getColumnIndexOrThrow(
                            DatabaseHelper.ITEM_ID
                    );

            int nameIndex =
                    cursor.getColumnIndexOrThrow(
                            DatabaseHelper.ITEM_NAME
                    );

            int quantityIndex =
                    cursor.getColumnIndexOrThrow(
                            DatabaseHelper.ITEM_QUANTITY
                    );

            int descriptionIndex =
                    cursor.getColumnIndexOrThrow(
                            DatabaseHelper.ITEM_DESCRIPTION
                    );

            while (cursor.moveToNext()) {

                int id =
                        cursor.getInt(idIndex);

                String name =
                        cursor.getString(nameIndex);

                int quantity =
                        cursor.getInt(quantityIndex);

                String description =
                        cursor.getString(
                                descriptionIndex
                        );

                InventoryItem item =
                        new InventoryItem(
                                id,
                                name,
                                quantity,
                                description
                        );

                items.add(item);
            }

        } finally {

            cursor.close();
        }

        return items;
    }
}