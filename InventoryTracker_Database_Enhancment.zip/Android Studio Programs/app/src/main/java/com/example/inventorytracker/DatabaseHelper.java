package com.example.inventorytracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    // =========================================================
    // DATABASE
    // =========================================================

    private static final String DATABASE_NAME =
            "InventoryTracker.db";

    private static final int DATABASE_VERSION = 2;

    // =========================================================
    // USERS TABLE
    // =========================================================

    public static final String TABLE_USERS = "users";

    public static final String USER_ID = "id";
    public static final String USERNAME = "username";

    // Password is no longer stored directly.
    public static final String PASSWORD_HASH = "password_hash";
    public static final String PASSWORD_SALT = "password_salt";

    // =========================================================
    // INVENTORY TABLE
    // =========================================================

    public static final String TABLE_INVENTORY = "inventory";

    public static final String ITEM_ID = "id";
    public static final String ITEM_NAME = "item_name";
    public static final String ITEM_QUANTITY = "quantity";
    public static final String ITEM_DESCRIPTION = "description";
    public static final String ITEM_CREATED_AT = "created_at";

    public DatabaseHelper(Context context) {
        super(
                context,
                DATABASE_NAME,
                null,
                DATABASE_VERSION
        );
    }

    // =========================================================
    // CREATE DATABASE
    // =========================================================

    @Override
    public void onCreate(SQLiteDatabase db) {

        createUsersTable(db);
        createInventoryTable(db);
        createInventoryNameIndex(db);
    }

    private void createUsersTable(SQLiteDatabase db) {

        String createUsersTable =
                "CREATE TABLE " + TABLE_USERS + " (" +
                        USER_ID +
                        " INTEGER PRIMARY KEY AUTOINCREMENT, " +

                        USERNAME +
                        " TEXT UNIQUE NOT NULL, " +

                        PASSWORD_HASH +
                        " TEXT NOT NULL, " +

                        PASSWORD_SALT +
                        " TEXT NOT NULL" +
                        ")";

        db.execSQL(createUsersTable);
    }

    private void createInventoryTable(SQLiteDatabase db) {

        String createInventoryTable =
                "CREATE TABLE " + TABLE_INVENTORY + " (" +

                        ITEM_ID +
                        " INTEGER PRIMARY KEY AUTOINCREMENT, " +

                        ITEM_NAME +
                        " TEXT NOT NULL CHECK(length(trim(" +
                        ITEM_NAME + ")) > 0), " +

                        ITEM_QUANTITY +
                        " INTEGER NOT NULL CHECK(" +
                        ITEM_QUANTITY + " >= 0), " +

                        ITEM_DESCRIPTION +
                        " TEXT, " +

                        ITEM_CREATED_AT +
                        " TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP" +

                        ")";

        db.execSQL(createInventoryTable);
    }

    private void createInventoryNameIndex(SQLiteDatabase db) {

        db.execSQL(
                "CREATE INDEX IF NOT EXISTS " +
                        "idx_inventory_name ON " +
                        TABLE_INVENTORY +
                        "(" + ITEM_NAME + ")"
        );
    }

    // =========================================================
    // DATABASE UPGRADE
    // =========================================================

    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion) {

        /*
         * Version 1 -> Version 2
         *
         * Inventory records are migrated instead of deleting
         * the entire database.
         *
         * Version 1 stored user passwords as plaintext.
         * Those passwords cannot be safely transformed into
         * salted hashes during a schema-only migration, so
         * version-1 accounts are removed and must be recreated.
         */

        if (oldVersion < 2) {

            migrateInventoryToVersion2(db);

            db.execSQL(
                    "DROP TABLE IF EXISTS " +
                            TABLE_USERS
            );

            createUsersTable(db);
            createInventoryNameIndex(db);
        }
    }

    private void migrateInventoryToVersion2(
            SQLiteDatabase db) {

        db.beginTransaction();

        try {

            db.execSQL(
                    "ALTER TABLE " +
                            TABLE_INVENTORY +
                            " RENAME TO inventory_old"
            );

            createInventoryTable(db);

            db.execSQL(
                    "INSERT INTO " +
                            TABLE_INVENTORY +
                            " (" +
                            ITEM_ID + ", " +
                            ITEM_NAME + ", " +
                            ITEM_QUANTITY + ", " +
                            ITEM_DESCRIPTION +
                            ") " +

                            "SELECT " +
                            ITEM_ID + ", " +
                            ITEM_NAME + ", " +
                            "CASE WHEN " +
                            ITEM_QUANTITY +
                            " < 0 THEN 0 ELSE " +
                            ITEM_QUANTITY +
                            " END, " +
                            ITEM_DESCRIPTION +

                            " FROM inventory_old " +

                            "WHERE " +
                            ITEM_NAME +
                            " IS NOT NULL " +

                            "AND length(trim(" +
                            ITEM_NAME +
                            ")) > 0"
            );

            db.execSQL(
                    "DROP TABLE inventory_old"
            );

            db.setTransactionSuccessful();

        } finally {

            db.endTransaction();
        }
    }

    // =========================================================
    // CREATE INVENTORY ITEM
    // =========================================================

    public boolean addInventoryItem(
            String name,
            int quantity,
            String description) {

        if (!isValidInventoryItem(name, quantity)) {
            return false;
        }

        SQLiteDatabase db =
                getWritableDatabase();

        ContentValues values =
                new ContentValues();

        values.put(
                ITEM_NAME,
                name.trim()
        );

        values.put(
                ITEM_QUANTITY,
                quantity
        );

        values.put(
                ITEM_DESCRIPTION,
                description == null
                        ? ""
                        : description.trim()
        );

        long result = db.insert(
                TABLE_INVENTORY,
                null,
                values
        );

        return result != -1;
    }

    // =========================================================
    // READ ALL INVENTORY
    // =========================================================

    public Cursor getAllInventoryItems() {

        SQLiteDatabase db =
                getReadableDatabase();

        return db.query(
                TABLE_INVENTORY,
                null,
                null,
                null,
                null,
                null,
                ITEM_NAME + " COLLATE NOCASE ASC"
        );
    }

    // =========================================================
    // SEARCH INVENTORY IN SQLITE
    // =========================================================

    public Cursor searchInventoryItems(
            String searchText) {

        SQLiteDatabase db =
                getReadableDatabase();

        String search =
                searchText == null
                        ? ""
                        : searchText.trim();

        return db.query(
                TABLE_INVENTORY,
                null,

                ITEM_NAME +
                        " LIKE ? COLLATE NOCASE",

                new String[]{
                        "%" + search + "%"
                },

                null,
                null,

                ITEM_NAME +
                        " COLLATE NOCASE ASC"
        );
    }

    // =========================================================
    // LOW STOCK QUERY
    // =========================================================

    public Cursor getLowStockInventoryItems(
            int threshold) {

        SQLiteDatabase db =
                getReadableDatabase();

        if (threshold < 0) {
            threshold = 0;
        }

        return db.query(
                TABLE_INVENTORY,
                null,

                ITEM_QUANTITY + " <= ?",

                new String[]{
                        String.valueOf(threshold)
                },

                null,
                null,

                ITEM_QUANTITY + " ASC"
        );
    }

    // =========================================================
    // INVENTORY LIST
    // =========================================================

    public List<InventoryItem> getInventoryItemList() {

        List<InventoryItem> inventoryItems =
                new ArrayList<>();

        Cursor cursor =
                getAllInventoryItems();

        try {

            while (cursor.moveToNext()) {

                inventoryItems.add(
                        cursorToInventoryItem(cursor)
                );
            }

        } finally {

            cursor.close();
        }

        return inventoryItems;
    }

    private InventoryItem cursorToInventoryItem(
            Cursor cursor) {

        int id =
                cursor.getInt(
                        cursor.getColumnIndexOrThrow(
                                ITEM_ID
                        )
                );

        String name =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                ITEM_NAME
                        )
                );

        int quantity =
                cursor.getInt(
                        cursor.getColumnIndexOrThrow(
                                ITEM_QUANTITY
                        )
                );

        String description =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                ITEM_DESCRIPTION
                        )
                );

        return new InventoryItem(
                id,
                name,
                quantity,
                description
        );
    }

    // =========================================================
    // UPDATE INVENTORY
    // =========================================================

    public boolean updateInventoryItem(
            int id,
            String name,
            int quantity,
            String description) {

        if (id <= 0 ||
                !isValidInventoryItem(
                        name,
                        quantity)) {

            return false;
        }

        SQLiteDatabase db =
                getWritableDatabase();

        ContentValues values =
                new ContentValues();

        values.put(
                ITEM_NAME,
                name.trim()
        );

        values.put(
                ITEM_QUANTITY,
                quantity
        );

        values.put(
                ITEM_DESCRIPTION,
                description == null
                        ? ""
                        : description.trim()
        );

        int result = db.update(
                TABLE_INVENTORY,
                values,

                ITEM_ID + " = ?",

                new String[]{
                        String.valueOf(id)
                }
        );

        return result > 0;
    }

    // =========================================================
    // DELETE INVENTORY
    // =========================================================

    public boolean deleteInventoryItem(
            int id) {

        if (id <= 0) {
            return false;
        }

        SQLiteDatabase db =
                getWritableDatabase();

        int result = db.delete(
                TABLE_INVENTORY,

                ITEM_ID + " = ?",

                new String[]{
                        String.valueOf(id)
                }
        );

        return result > 0;
    }

    // =========================================================
    // INVENTORY VALIDATION
    // =========================================================

    private boolean isValidInventoryItem(
            String name,
            int quantity) {

        return name != null &&
                !name.trim().isEmpty() &&
                quantity >= 0;
    }

    // =========================================================
    // CREATE USER
    // =========================================================

    public boolean createUser(
            String username,
            String password) {

        if (username == null ||
                username.trim().isEmpty() ||
                password == null ||
                password.length() < 4) {

            return false;
        }

        SQLiteDatabase db =
                getWritableDatabase();

        byte[] salt =
                generateSalt();

        String saltText =
                bytesToHex(salt);

        String passwordHash =
                hashPassword(
                        password,
                        salt
                );

        if (passwordHash == null) {
            return false;
        }

        ContentValues values =
                new ContentValues();

        values.put(
                USERNAME,
                username.trim()
        );

        values.put(
                PASSWORD_HASH,
                passwordHash
        );

        values.put(
                PASSWORD_SALT,
                saltText
        );

        long result = db.insert(
                TABLE_USERS,
                null,
                values
        );

        return result != -1;
    }

    // =========================================================
    // CHECK USER LOGIN
    // =========================================================

    public boolean checkUser(
            String username,
            String password) {

        if (username == null ||
                password == null) {

            return false;
        }

        SQLiteDatabase db =
                getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_USERS,

                new String[]{
                        PASSWORD_HASH,
                        PASSWORD_SALT
                },

                USERNAME + " = ?",

                new String[]{
                        username.trim()
                },

                null,
                null,
                null
        );

        try {

            if (!cursor.moveToFirst()) {
                return false;
            }

            String storedHash =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    PASSWORD_HASH
                            )
                    );

            String storedSalt =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    PASSWORD_SALT
                            )
                    );

            byte[] salt =
                    hexToBytes(storedSalt);

            String enteredPasswordHash =
                    hashPassword(
                            password,
                            salt
                    );

            return storedHash.equals(
                    enteredPasswordHash
            );

        } finally {

            cursor.close();
        }
    }

    // =========================================================
    // PASSWORD SECURITY
    // =========================================================

    private byte[] generateSalt() {

        SecureRandom secureRandom =
                new SecureRandom();

        byte[] salt =
                new byte[16];

        secureRandom.nextBytes(salt);

        return salt;
    }

    private String hashPassword(
            String password,
            byte[] salt) {

        try {

            MessageDigest digest =
                    MessageDigest.getInstance(
                            "SHA-256"
                    );

            digest.update(salt);

            byte[] hashedPassword =
                    digest.digest(
                            password.getBytes(
                                    StandardCharsets.UTF_8
                            )
                    );

            return bytesToHex(
                    hashedPassword
            );

        } catch (Exception e) {

            return null;
        }
    }

    private String bytesToHex(
            byte[] bytes) {

        StringBuilder builder =
                new StringBuilder();

        for (byte value : bytes) {

            builder.append(
                    String.format(
                            "%02x",
                            value & 0xff
                    )
            );
        }

        return builder.toString();
    }

    private byte[] hexToBytes(
            String hex) {

        int length = hex.length();

        byte[] data =
                new byte[length / 2];

        for (int i = 0;
             i < length;
             i += 2) {

            data[i / 2] =
                    (byte) (
                            (Character.digit(
                                    hex.charAt(i),
                                    16
                            ) << 4)

                                    +

                                    Character.digit(
                                            hex.charAt(i + 1),
                                            16
                                    )
                    );
        }

        return data;
    }
}