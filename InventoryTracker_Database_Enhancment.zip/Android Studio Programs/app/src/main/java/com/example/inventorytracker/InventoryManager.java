package com.example.inventorytracker;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class InventoryManager {

    /**
     * Searches inventory items by name.
     *
     * Time complexity: O(n)
     */
    public static List<InventoryItem> searchByName(
            List<InventoryItem> inventory,
            String searchText) {

        List<InventoryItem> results = new ArrayList<>();

        if (inventory == null) {
            return results;
        }

        if (searchText == null || searchText.trim().isEmpty()) {
            results.addAll(inventory);
            return results;
        }

        String searchValue = searchText.trim().toLowerCase();

        for (InventoryItem item : inventory) {

            if (item.getName()
                    .toLowerCase()
                    .contains(searchValue)) {

                results.add(item);
            }
        }

        return results;
    }

    /**
     * Sorts inventory alphabetically by item name.
     *
     * A copy is created so the original list is not modified.
     */
    public static List<InventoryItem> sortByName(
            List<InventoryItem> inventory) {

        List<InventoryItem> sortedItems =
                new ArrayList<>(inventory);

        Collections.sort(
                sortedItems,
                Comparator.comparing(
                        InventoryItem::getName,
                        String.CASE_INSENSITIVE_ORDER
                )
        );

        return sortedItems;
    }

    /**
     * Sorts inventory from lowest quantity to highest quantity.
     */
    public static List<InventoryItem> sortByQuantity(
            List<InventoryItem> inventory) {

        List<InventoryItem> sortedItems =
                new ArrayList<>(inventory);

        Collections.sort(
                sortedItems,
                Comparator.comparingInt(
                        InventoryItem::getQuantity
                )
        );

        return sortedItems;
    }

    /**
     * Finds inventory items at or below the specified
     * low-stock threshold.
     *
     * Time complexity: O(n)
     */
    public static List<InventoryItem> getLowStockItems(
            List<InventoryItem> inventory,
            int threshold) {

        List<InventoryItem> lowStockItems =
                new ArrayList<>();

        for (InventoryItem item : inventory) {

            if (item.getQuantity() <= threshold) {
                lowStockItems.add(item);
            }
        }

        return lowStockItems;
    }
}