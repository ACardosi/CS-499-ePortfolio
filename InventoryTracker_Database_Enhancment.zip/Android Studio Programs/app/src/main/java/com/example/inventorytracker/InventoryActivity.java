package com.example.inventorytracker;

import android.content.Intent;
import java.util.List;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class InventoryActivity extends AppCompatActivity {

    private Button buttonAddItem;
    private LinearLayout inventoryContainer;
    private Button buttonSmsSettings;
    private InventoryRepository inventoryRepository;
    private EditText editSearch;

    private Button buttonSearch;
    private Button buttonSortName;
    private Button buttonSortQuantity;
    private Button buttonLowStock;
    private Button buttonShowAll;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_inventory);

        // Connect Java variables to the XML layout.
        buttonAddItem = findViewById(R.id.buttonAddItem);
        buttonSmsSettings = findViewById(R.id.buttonSmsSettings);
        inventoryContainer = findViewById(R.id.inventoryContainer);

        editSearch =
                findViewById(R.id.editSearch);

        buttonSearch =
                findViewById(R.id.buttonSearch);

        buttonSortName =
                findViewById(R.id.buttonSortName);

        buttonSortQuantity =
                findViewById(R.id.buttonSortQuantity);

        buttonLowStock =
                findViewById(R.id.buttonLowStock);

        buttonShowAll =
                findViewById(R.id.buttonShowAll);


        buttonSearch.setOnClickListener(v -> {

            String searchText =
                    editSearch.getText()
                            .toString()
                            .trim();

            List<InventoryItem> results =
                    inventoryRepository.searchItems(
                            searchText
                    );

            displayInventory(results);
        });

        buttonSortName.setOnClickListener(v -> {

            List<InventoryItem> items =
                    inventoryRepository.getAllItems();

            List<InventoryItem> sortedItems =
                    InventoryManager.sortByName(items);

            displayInventory(sortedItems);
        });

        buttonSortQuantity.setOnClickListener(v -> {

            List<InventoryItem> items =
                    inventoryRepository.getAllItems();

            List<InventoryItem> sortedItems =
                    InventoryManager.sortByQuantity(items);

            displayInventory(sortedItems);
        });

        buttonLowStock.setOnClickListener(v -> {

            List<InventoryItem> lowStockItems =
                    inventoryRepository.getLowStockItems(
                            5
                    );

            displayInventory(lowStockItems);
        });

        buttonShowAll.setOnClickListener(v -> {

            editSearch.setText("");

            loadInventory();
        });

        // Create the repository used to manage inventory data.
        inventoryRepository = new InventoryRepository(this);


        buttonSmsSettings.setOnClickListener(v -> {

            Intent intent = new Intent(
                    InventoryActivity.this,
                    SmsActivity.class
            );

            startActivity(intent);
        });

        // Open the Add Item screen.
        buttonAddItem.setOnClickListener(v -> {

            Intent intent = new Intent(
                    InventoryActivity.this,
                    AddItemActivity.class
            );

            startActivity(intent);
        });

        // Display the inventory.
        loadInventory();
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Refresh inventory when returning from AddItemActivity.
        if (inventoryContainer != null) {
            loadInventory();
        }
    }

    private void loadInventory() {

        List<InventoryItem> items =
                inventoryRepository.getAllItems();

        displayInventory(items);
    }

    private void displayInventory(
            List<InventoryItem> items) {

        // Remove existing rows before rebuilding the list.
        inventoryContainer.removeAllViews();

        // Display a message when there are no inventory items.
        if (items == null || items.isEmpty()) {

            TextView emptyMessage =
                    new TextView(this);

            emptyMessage.setText(
                    "No inventory items found."
            );

            emptyMessage.setPadding(
                    8,
                    24,
                    8,
                    24
            );

            inventoryContainer.addView(
                    emptyMessage
            );

            return;
        }

        // Create a row for each inventory item.
        for (InventoryItem item : items) {

            createInventoryRow(item);
        }
    }



    private void createInventoryRow(
            InventoryItem item) {

        // Create the horizontal row.
        LinearLayout row =
                new LinearLayout(this);

        row.setOrientation(
                LinearLayout.HORIZONTAL
        );

        row.setGravity(
                Gravity.CENTER_VERTICAL
        );

        row.setPadding(
                8,
                8,
                8,
                8
        );

        // -------------------------
        // ITEM NAME
        // -------------------------

        TextView nameView =
                new TextView(this);

        nameView.setText(item.getName());

        LinearLayout.LayoutParams nameParams =
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        2
                );

        nameView.setLayoutParams(nameParams);

        // -------------------------
        // QUANTITY
        // -------------------------

        TextView quantityView =
                new TextView(this);

        quantityView.setText(
                String.valueOf(item.getQuantity())
        );

        LinearLayout.LayoutParams quantityParams =
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        1
                );

        quantityView.setLayoutParams(quantityParams);

        // -------------------------
        // EDIT BUTTON
        // -------------------------

        Button editButton =
                new Button(this);

        editButton.setText("Edit");

        editButton.setOnClickListener(v -> {

            Intent intent = new Intent(
                    InventoryActivity.this,
                    AddItemActivity.class
            );

            // Send existing information to AddItemActivity.
            intent.putExtra(
                    "ITEM_ID",
                    item.getId()
            );

            intent.putExtra(
                    "ITEM_NAME",
                    item.getName()
            );

            intent.putExtra(
                    "ITEM_QUANTITY",
                    item.getQuantity()
            );

            intent.putExtra(
                    "ITEM_DESCRIPTION",
                    item.getDescription()
            );

            startActivity(intent);
        });

        // -------------------------
        // DELETE BUTTON
        // -------------------------

        Button deleteButton =
                new Button(this);

        deleteButton.setText("Delete");

        deleteButton.setOnClickListener(v -> {

            boolean deleted =
                    inventoryRepository.deleteItem(
                            item.getId()
                    );

            if (deleted) {

                Toast.makeText(
                        this,
                        "Item deleted.",
                        Toast.LENGTH_SHORT
                ).show();

                // Refresh the screen.
                loadInventory();

            } else {

                Toast.makeText(
                        this,
                        "Unable to delete item.",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        // Add everything to the row.
        row.addView(nameView);
        row.addView(quantityView);
        row.addView(editButton);
        row.addView(deleteButton);

        // Add the row to the inventory screen.
        inventoryContainer.addView(row);
    }
}